package egovframework.sample.service;

import java.util.List;

public interface BooksDAO {

//	void insertBook(BooksVO vo) throws Exception;
//
//	void deleteBook(BooksVO vo) throws Exception;
//
//	void updateBook(BooksVO vo) throws Exception;
	
	
	// where id
	BooksVO selectBook(BooksVO vo) throws Exception;
	
//	List<BooksVO> selectBookList(BooksVO vo) throws Exception;


}
