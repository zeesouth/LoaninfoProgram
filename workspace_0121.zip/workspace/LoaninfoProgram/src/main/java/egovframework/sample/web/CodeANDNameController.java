package egovframework.sample.web;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import egovframework.sample.service.UsersService;
import egovframework.sample.service.UsersVO;

public class CodeANDNameController implements Controller
{
	@Override
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		System.out.println("회원 & 책코드 , 회원이름 검색 기능 처리");
		AbstractApplicationContext container = new GenericXmlApplicationContext(
				"egovframework/spring/context-*.xml"
				);
		UsersService usersService = (UsersService) container.getBean("usersService");
		
		// req로 받아온 정보 추출
		String name = request.getParameter("name");
		String code = request.getParameter("code");
		
		UsersVO vo = new UsersVO();
		boolean canResult = false;
		
		// 들어온 값 둘다 공란일 경우
		if(name.equals("") && code.equals("")) {
			canResult = false;
		} else {
			
			// code만 존재
			if (name.equals("")) {
				
			} 
			// book & user만 존재
			else if (code.equals("")) {
				
			}
			// book & code 둘다 입력 
			else {
				canResult = false;
			}
			
		}
		
		
		// 3. 화면 네비게이션
		ModelAndView mav = new ModelAndView();
		mav.addObject("canResult", canResult);
		mav.setViewName("/index.jsp");
		container.close();
		return mav;
	}
}
