
select * from loaninfo;


select * from users;

select * from BOOKS;

select * from ids;
