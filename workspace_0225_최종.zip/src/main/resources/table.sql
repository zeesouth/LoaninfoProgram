select * from BOOKS;

select * from IDS;

select * from LOANINFO;

select * from USERS;