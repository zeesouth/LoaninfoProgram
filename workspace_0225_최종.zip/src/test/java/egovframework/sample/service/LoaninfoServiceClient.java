package egovframework.sample.service;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class LoaninfoServiceClient {
//	public static void main(String[] args) throws Exception {
//		// 1. Spring 컨테이너를 구동한다.
//		AbstractApplicationContext container = new GenericXmlApplicationContext(
//				"egovframework/spring/context-*.xml"
//				);
//		
//		// 2. Spring 컨테이너로부터 LoaninfoProgramServiceImpl 객체를 lookup한다.
//		
//		UsersService usersService = (UsersService) container.getBean("usersService");
//		
//		//1. 사용자 입력 정보 추출
//
//				UsersVO vo = new UsersVO();
//				
//				System.out.println(vo.getId());
//				vo.setName("남지수");
//				vo.setPhoneNum("010-1111-1111");
//				vo.setAddress("당정역로 9");
//				vo.setInfo("infoinfo");
//				
//				usersService.insertUser(vo);
//				UsersVO user = usersService.selectUserI(vo);
//				System.out.println(user.getId());
//				
//				
//				container.close();
//		
//		
//		
//		
//	}
	

}
