package egovframework.sample.service;

import java.sql.Date;

public class LoaninfoVO extends SelectVO {
	
	private String id;
	private int u_id;
	private String b_id;
	private Date loanDate;
	private Date returnDate;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getU_id() {
		return u_id;
	}
	public void setU_id(int u_id) {
		this.u_id = u_id;
	}
	public String getB_id() {
		return b_id;
	}
	public void setB_id(String b_id) {
		this.b_id = b_id;
	}
	public Date getLoanDate() {
		return loanDate;
	}
	public void setLoanDate(Date loanDate) {
		this.loanDate = loanDate;
	}
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	@Override
	public String toString() {
		return "LoaninfoVO [id=" + id + ", u_id=" + u_id + ", b_id=" + b_id + ", loanDate=" + loanDate + ", returnDate="
				+ returnDate + "]";
	}
	
	
	
}
