package egovframework.sample.service;

import java.util.List;

public interface LoaninfoService {

	void insertLoaninfo(LoaninfoVO v) throws Exception;
	
	// where id, u_id
	void updateLoaninfoIU(LoaninfoVO v) throws Exception;
		
	// where id, b_id
	void updateLoaninfoIB(LoaninfoVO v) throws Exception;

	// where b_id, loandate, returndate
	LoaninfoVO selectLoaninfoBLR(LoaninfoVO v) throws Exception;
		
	// where u_id, b_id, loandate, returndate
	LoaninfoVO selectLoaninfoUBLR(LoaninfoVO v) throws Exception;
	
	// where u_id
	List<LoaninfoVO> selectLoaninfoList(LoaninfoVO v) throws Exception;
	
	List<LoaninfoVO> selectLoaninfoList_notme(LoaninfoVO vo) throws Exception;
	
	int selectLoaninfoListTotCnt(LoaninfoVO vo) throws Exception;

}